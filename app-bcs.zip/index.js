const express = require("express");
const { default: mongoose } = require("mongoose");
const authRouter = require("./authRouter");
const PORT = process.env.PORT || 5000;
const app = express();
var cors = require("cors");
app.use(express.json());
app.use(cors());
app.use("/auth", authRouter);

const start = async () => {
  try {
    await mongoose.connect(
      "mongodb+srv://nicksqain:kekys123@app-bcs.wrl8p.mongodb.net/app-bcs?retryWrites=true&w=majority"
    );
    app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
  } catch (e) {
    console.log(e);
  }
};

start();
