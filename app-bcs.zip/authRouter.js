const Router = require("express");
const router = new Router();
const controller = require("./authController");
const { check } = require("express-validator");
var cors = require("cors");
const authMiddleWare = require("./middleware/authMiddleWare");
const roleMiddleWare = require("./middleware/rolemiddleWare");
var corsOptions = {
  origin: "http://127.0.0.1:5500",
  optionsSuccessStatus: 200, // some legacy browsers (IE11, various SmartTVs) choke on 204
};
// Регистрация
router.post(
  "/registration",
  [
    check("username", "Имя пользователя не может быть пустым!").notEmpty(),
    check("password", "Пароль должен состоять от 4 до 12 символов!").isLength({
      min: 4,
      max: 12,
    }),
  ],
  controller.registration
);
// Авторизация
router.post("/login", cors(), controller.login);
// Изменение описания пользователя
router.put("/changeAbout", controller.changeAbout);
//  Получение списка пользователей
router.get("/users", roleMiddleWare(["USER"]), controller.getUsers);

module.exports = router;
