// fetch("http://localhost:5000/auth/login", {
//   method: "POST",
//   body: JSON.stringify({
//     username: "Nicksqain",
//     password: "kekys123",
//   }),
// }).then((response) => response.json());

// (async () => {
//   const rawResponse = await fetch("http://localhost:5000/auth/login", {
//     method: "POST",
//     headers: {
//       Accept: "application/json",
//       "Content-Type": "application/json",
//     },
//     body: JSON.stringify({
//       username: "Nicksqain",
//       password: "kekys123",
//     }),
//   });
//   const content = await rawResponse.json();

//   console.log(content);
// })();

function summary(count) {
  let str = "";
  let i = 1;
  while (str.length <= count - 1) {
    str += i.toString();
    i++;
  }
  str.length < 10 ? (x = 1) : (x = 2);
  return str.slice(-x);
}
console.log(summary(2));
