module.exports = {
  secretPrivateKey: "ABOBUS",
};
