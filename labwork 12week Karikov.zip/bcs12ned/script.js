// Импорты
var fileSystem = require("fs");
const readline = require("readline");

// Получение контента с файла
let inputText = "";
try {
  inputText = fileSystem.readFileSync("./input.txt", "utf8");
} catch (err) {
  console.error(err);
}

// Получение фидбэка
let cryptMode;
const prompt = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
prompt.question(
  "Введите режим (1 - Шифрация, 2 - Дешифрация): ",
  function (mode) {
    cryptMode = mode;
    prompt.close();
  }
);

// Случайное число
function getRandomInt(max) {
  return Math.floor(Math.random() * max);
}

//  --- Шифрация ---

let message = inputText;
let key = getRandomInt(987654321).toString();

key = key.split("");

// Дополнение ключа по длине
while (message.length > key.length) {
  for (let i = 0; i <= key.length; i++) {
    key.push(key[i]);
    if (message.length == key.length) {
      break;
    }
  }
}

// Функция шифрации
let encryption = (str) => {
  array = [];
  finalArray = [];

  for (let i = 0; i < str.length; i++) {
    let symbol = str.charCodeAt(i) + Number(key[i]);
    array.push(symbol);
  }
  for (let k = 0; k < array.length; k++) {
    x = String.fromCharCode(array[k]);
    finalArray.push(x);
  }
  return finalArray.join("");
};

// Функция дешифрации
let decryption = (str) => {
  array = [];
  finalArray = [];
  for (let i = 0; i < str.length; i++) {
    let symbol = str.charCodeAt(i) - Number(key[i]);
    array.push(symbol);
  }
  for (let k = 0; k < array.length; k++) {
    x = String.fromCharCode(array[k]);
    finalArray.push(x);
  }
  return finalArray.join("");
};

// Скручивание инпута
prompt.on("close", function () {
  cryptMode === "1" ? console.log("Режим: Шифрация") : void 0;
  cryptMode === "2" ? console.log("Режим: Дешифрация") : void 0;
  cryptMode != "1" && cryptMode != "2"
    ? console.log("Вы не выбрали режим!")
    : void 0;
  // Обработка значений режима
  function checkMode() {
    if (cryptMode === "1") {
      return encryption(message);
    } else {
      return decryption(message);
    }
  }
  // Перезапись сообщения
  fileSystem.writeFileSync(
    "input.txt",
    checkMode().toString(),
    "utf8",
    (err) => {
      if (err) throw err;
    }
  );
  // завершить сессию
  process.exit(0);
});
